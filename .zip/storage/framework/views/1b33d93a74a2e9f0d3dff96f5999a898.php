<nav class="sidebar">
<div class="logo d-flex justify-content-between">
<a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('img/Final PNG (transparent background)-01.png')); ?>"></a>
<div class="sidebar_close_icon d-lg-none">
<i class="ti-close"></i>
</div>
</div>

<?php echo $__env->make('layouts.backend.link.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</nav><?php /**PATH C:\xampp\htdocs\NestNortify\resources\views/layouts/backend/navbar.blade.php ENDPATH**/ ?>