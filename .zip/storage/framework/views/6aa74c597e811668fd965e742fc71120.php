<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from demo.dashboardpack.com/finance-html/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 01 May 2023 06:55:21 GMT -->
<head>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<title>NestNotify</title>
<link rel="icon" href="img/logosmall.png" type="image/png">

<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap1.min.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('vendors/themefy_icon/themify-icons.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('vendors/swiper_slider/css/swiper.min.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('vendors/select2/css/select2.min.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('vendors/niceselect/css/nice-select.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('vendors/owl_carousel/css/owl.carousel.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('vendors/gijgo/gijgo.min.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('vendors/font_awesome/css/all.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('vendors/tagsinput/tagsinput.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('vendors/datatable/css/jquery.dataTables.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('vendors/datatable/css/responsive.dataTables.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('vendors/datatable/css/buttons.dataTables.min.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('vendors/text_editor/summernote-bs4.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('vendors/morris/morris.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('vendors/material_icon/material-icons.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('css/metisMenu.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/style1.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/colors/default.css')); ?>" id="colorSkinCSS">

<script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-sortablejs@latest/jquery-sortable.js"></script>


</head>
<body class="crm_body_bg">

<?php /**PATH C:\xampp\htdocs\NestNortify\resources\views/layouts/backend/header.blade.php ENDPATH**/ ?>