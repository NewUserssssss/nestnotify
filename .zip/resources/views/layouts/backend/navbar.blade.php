<nav class="sidebar">
<div class="logo d-flex justify-content-between">
<a href="{{url('/')}}"><img src="{{asset('img/Final PNG (transparent background)-01.png')}}"></a>
<div class="sidebar_close_icon d-lg-none">
<i class="ti-close"></i>
</div>
</div>

@include('layouts.backend.link.sidebar')

</nav>