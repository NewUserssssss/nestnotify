<ul id="sidebar_menu">
<li class="mm-active">
<a class="has-arrow" href="#" aria-expanded="false">

<img src="img/menu-icon/1.svg" alt="">
<span>Dashboard</span>
</a>
<ul>
<li><a class="active" href="{{url('/')}}">Classic</a></li>
<li><a href="{{url('/')}}">Minimal</a></li>
</ul>
</li>
<li class="">
<a class="has-arrow" href="#" aria-expanded="false">
<img src="img/menu-icon/2.svg" alt="">
<span>Frontend</span>
</a>
<ul>
<li><a href="{{url('login')}}">Login</a></li>
<li><a href="{{url('resister')}}">Register</a></li>
<li><a href="{{url('forgot_pass')}}">Forgot Password</a></li>
</ul>
</li>
<li class="">
<a class="has-arrow" href="#" aria-expanded="false">
<img src="img/menu-icon/3.svg" alt="">
<span>Questionnare</span>
</a>
<ul>
<li><a href="{{url('Add_Questions')}}">Add Questions</a></li>
<li><a href="{{url('Edit_Question')}}">Edit Question</a></li>
<li><a href="{{url('faq')}}">FAQ</a></li>
</ul>
</li>
<li class="">
<a class="has-arrow" href="#" aria-expanded="false">
<img src="img/menu-icon/4.svg" alt="">
<span>UI Component</span>
</a>
<ul>
<li><a href="#">Elements</a>
<ul>
<li><a href="{{url('buttons')}}">Buttons</a></li>
<li><a href="{{url('dropdown')}}">Dropdowns</a></li>
 <li><a href="{{url('badges')}}">Badges</a></li>
<li><a href="{{url('Loading_Indicators')}}">Loading Indicators</a></li>
</ul>
</li>
<li><a href="#">Components</a>
<ul>
<li><a href="{{url('notification')}}">Notifications</a></li>
<li><a href="{{url('progress')}}">Progress Bar</a></li>
<li><a href="{{url('carousel')}}">Carousel</a></li>
<li><a href="{{url('cards')}}">cards</a></li>
<li><a href="{{url('Pagination')}}">Pagination</a></li>
</ul>
</li>
</ul>
</li>
<li class="">
<a class="has-arrow" href="#" aria-expanded="false">
<img src="img/menu-icon/5.svg" alt="">
<span>Widgets</span>
</a>
<ul>
<li><a href="{{url('chart_box')}}">Chart Boxes 1</a></li>
<li><a href="{{url('profilebox')}}">Profile Box</a></li>
</ul>
</li>
<li class="">
<a class="has-arrow" href="#" aria-expanded="false">
<img src="img/menu-icon/6.svg" alt="">
<span>Forms</span>
</a>
<ul>
<li><a href="#">Elements</a>
<ul>
<li><a href="{{url('data_table')}}">Data Tables</a></li>
<li><a href="{{url('boot_table')}}">Grid Tables</a></li>
<li><a href="{{url('datepicker')}}">Date Picker</a></li>
</ul>
</li>
<li><a href="#">Widgets</a>
<ul>
<li><a href="{{url('input_Selects')}}">Input Selects</a></li>
<li><a href="{{url('input_mask')}}">Input Mask</a></li>
</ul>
</li>
</ul>
</li>
<li class="">
<a class="has-arrow" href="#" aria-expanded="false">
<img src="img/menu-icon/7.svg" alt="">
<span>Charts</span>
</a>
<ul>
<li><a href="{{url('chartjs')}}">ChartJS</a></li>
<li><a href="{{url('apex')}}">Apex Charts</a></li>
<li><a href="{{url('chart_spark')}}">chart sparkline</a></li>
</ul>
</li>
</ul>