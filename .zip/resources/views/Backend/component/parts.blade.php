@include('layouts.backend.header')

@include('layouts.backend.navbar')

  @yield('contents')


@include('layouts.backend.footer')